function multile(params) {
    
    let giro= 40;
    
    if (giro == f || f >= 1 && f == giro &&  f++){
        var f=52; 
        document.write(f);
         
    } else console.log("what")
};